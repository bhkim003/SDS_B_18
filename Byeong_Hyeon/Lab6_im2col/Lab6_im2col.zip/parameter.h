#define H 32 // row of input feature map
#define W 32 // col of input feature map
#define C 64 // channel of input feature map

#define Cout 32 // output channel
#define K 3     // filter size

#define STRIDE 1
#define P 1 // padding size